name: hydro~datadrop~1.0
description: This is a Vert.X Module implementation
author: ezrak